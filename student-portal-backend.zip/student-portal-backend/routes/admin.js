const express = require("express");
const router = express.Router();
const { adminLogin, addAdmin } = require("../controllers/adminController");

// Login route
router.post("/login", adminLogin);

// Add new admin (you can later add auth middleware for role check)
router.post("/add", addAdmin);

module.exports = router;