const express = require("express");

const router = express.Router();
const { studentLogin } = require("../controllers/authController");
const { adminLogin } = require("../controllers/authController");
const { createAdmin } = require("../controllers/adminController");
const checkSuperAdmin = require("../middleware/checkRole");

router.post("/add-admin", checkSuperAdmin, createAdmin);

router.post("/admin-login", adminLogin);

router.post("/student-login", studentLogin);

module.exports = router;