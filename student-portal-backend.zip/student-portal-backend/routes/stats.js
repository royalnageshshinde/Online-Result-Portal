const express = require("express");
const router = express.Router();
const { saveStats, getAllStats } = require("../controllers/statController");

// POST /api/stats/save
router.post("/save", saveStats);

// GET /api/stats
router.get("/", getAllStats);

module.exports = router;