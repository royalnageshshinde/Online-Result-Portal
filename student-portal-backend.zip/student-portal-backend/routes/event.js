const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const { addEvent } = require("../controllers/eventController");

// Storage setup
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, "uploads/"); // upload folder
    },
    filename: function(req, file, cb) {
        const uniqueName = Date.now() + "-" + file.originalname;
        cb(null, uniqueName);
    },
});

const upload = multer({ storage });

// POST /api/events/add
router.post(
    "/add",
    upload.fields([
        { name: "poster", maxCount: 1 },
        { name: "gallery", maxCount: 10 },
    ]),
    addEvent
);

module.exports = router;