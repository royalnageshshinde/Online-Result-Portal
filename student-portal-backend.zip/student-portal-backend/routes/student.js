const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const Marksheet = require("../models/marksheet");
const { submitInfoAndFetchResult } = require("../controllers/studentController");

// ✅ Multer config
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, "uploads/");
    },
    filename: function(req, file, cb) {
        const uniqueName = Date.now() + path.extname(file.originalname);
        cb(null, uniqueName);
    },
});
const upload = multer({ storage });

// 📥 Student uploads result (by admin)
router.post("/upload-result", upload.single("file"), async(req, res) => {
    try {
        console.log("BODY:", req.body);
        console.log("FILE:", req.file);

        const { name, prn, year } = req.body;

        if (!req.file) {
            return res.status(400).json({ message: "❌ No file uploaded" });
        }

        const resultFilePath = req.file.filename;

        const newMarksheet = new Marksheet({
            studentName: name,
            studentPRN: prn,
            year,
            resultFilePath,
        });

        await newMarksheet.save();

        res.status(200).json({ message: "✅ Result uploaded successfully!" });
    } catch (err) {
        console.error("❌ Upload error:", err.message);
        res.status(500).json({ message: "❌ Upload failed", error: err.message });
    }
});

// 🧾 Student tries to fetch result
router.post("/info", submitInfoAndFetchResult);


module.exports = router;