// middleware/checkRole.js
const jwt = require("jsonwebtoken");
const Admin = require("../models/Admin");

const checkSuperAdmin = async(req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        const token = authHeader && authHeader.split(" ")[1];
        if (!token) return res.status(401).json({ message: "No token provided" });

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const admin = await Admin.findById(decoded.id);

        if (!admin || admin.role !== "superadmin") {
            return res.status(403).json({ message: "Access denied. Not superadmin." });
        }

        req.admin = admin; // Attach to request for use later
        next();
    } catch (err) {
        return res.status(500).json({ message: "Unauthorized", error: err.message });
    }
};

module.exports = checkSuperAdmin;