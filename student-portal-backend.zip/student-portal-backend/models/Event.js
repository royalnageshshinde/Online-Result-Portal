const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: String,
    eventDate: String,
    coverImage: String, // path of uploaded poster
    galleryImages: [String], // paths of gallery images
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("Event", eventSchema);