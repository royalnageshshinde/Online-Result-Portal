const mongoose = require('mongoose');

const marksheetSchema = new mongoose.Schema({
    studentPRN: {
        type: String,
        required: true,
    },
    studentName: {
        type: String,
        required: true,
    },
    year: {
        type: String,
        enum: ['First Year', 'Second Year', 'Third Year', 'Final Year'],
        required: true,
    },
    resultFilePath: {
        type: String,
        required: true,
    },
    uploadedAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Marksheet', marksheetSchema);