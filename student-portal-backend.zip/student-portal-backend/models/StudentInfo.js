const mongoose = require('mongoose');

const studentInfoSchema = new mongoose.Schema({
    fullName: { type: String, required: true },
    prn: { type: String, required: true, unique: true },
    branch: { type: String, required: true },
    year: { type: String, required: true },
    submittedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("StudentInfo", studentInfoSchema);