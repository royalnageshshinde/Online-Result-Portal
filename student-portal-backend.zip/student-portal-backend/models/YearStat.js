const mongoose = require("mongoose");

const yearStatSchema = new mongoose.Schema({
    year: { type: String, required: true, unique: true },
    pass: { type: Number, required: true },
    fail: { type: Number, required: true },
    total: { type: Number, required: true },
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("YearStat", yearStatSchema);