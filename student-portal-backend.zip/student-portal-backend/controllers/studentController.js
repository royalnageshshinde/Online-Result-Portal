const StudentInfoForm = require("../models/StudentInfo");
const Marksheet = require("../models/marksheet");

exports.submitInfoAndFetchResult = async(req, res) => {
    const { fullName, prn, branch, year } = req.body;

    try {
        // Save to the new collection
        const info = new StudentInfoForm({ fullName, prn, branch, year });
        await info.save();

        // Fetch result from Marksheet collection (optional)
        const result = await Marksheet.findOne({ studentPRN: prn, year });

        if (!result) {
            return res.status(200).json({ message: "Info saved, but result not uploaded yet.", resultAvailable: false });
        }

        return res.status(200).json({
            message: "Info saved. Result found.",
            resultAvailable: true,
            resultData: result
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Server error", error: err.message });
    }
};
const uploadMarksheet = async(req, res) => {
    try {
        const { name, prn, year } = req.body;

        if (!req.file) {
            return res.status(400).json({ error: "No file uploaded" });
        }

        const newMarksheet = new Marksheet({
            studentName: name,
            studentPRN: prn,
            year,
            resultFilePath: req.file.filename,
        });

        await newMarksheet.save();
        res.status(200).json({ message: "✅ Uploaded & saved!" });
    } catch (err) {
        console.error("❌ Upload error:", err);
        res.status(500).json({ error: "Upload failed" });
    }
};

// 🎯 For student – to fetch result
const submitInfoAndFetchResult = async(req, res) => {
    try {
        const { fullName, prn, year } = req.body;

        const resultData = await Marksheet.findOne({
            studentName: fullName,
            studentPRN: prn,
            year,
        });

        if (resultData) {
            res.status(200).json({ resultAvailable: true, resultData });
        } else {
            res.status(200).json({ resultAvailable: false });
        }
    } catch (err) {
        console.error("❌ Fetch error:", err);
        res.status(500).json({ error: "Server error" });
    }
};

module.exports = {
    uploadMarksheet,
    submitInfoAndFetchResult,
};