const YearStat = require("../models/YearStat");

exports.saveStats = async(req, res) => {
    const { year, pass, fail, total } = req.body;

    try {
        const existing = await YearStat.findOne({ year });

        if (existing) {
            existing.pass = pass;
            existing.fail = fail;
            existing.total = total;
            existing.updatedAt = Date.now();
            await existing.save();
        } else {
            await YearStat.create({ year, pass, fail, total });
        }

        res.status(200).json({ message: "✅ Stats saved successfully!" });
    } catch (err) {
        console.error("❌ Error saving stats", err);
        res.status(500).json({ message: "Something went wrong." });
    }
};

exports.getAllStats = async(req, res) => {
    try {
        const allStats = await YearStat.find({});
        res.status(200).json(allStats);
    } catch (err) {
        res.status(500).json({ message: "Error fetching stats." });
    }
};