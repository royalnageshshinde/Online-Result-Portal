const Event = require("../models/Event");

// POST /api/events/add
exports.addEvent = async(req, res) => {
    try {
        const { title, description, eventDate } = req.body;

        // File paths from multer
        let coverImage = "";
        let galleryImages = [];

        if (req.files && req.files["poster"] && req.files["poster"].length > 0) {
            coverImage = req.files["poster"][0].filename;
        }

        if (req.files && req.files["gallery"] && req.files["gallery"].length > 0) {
            galleryImages = req.files["gallery"].map(file => file.filename);
        }


        const newEvent = new Event({
            title,
            description,
            eventDate,
            coverImage,
            galleryImages,
        });

        await newEvent.save();
        res.status(201).json({ message: "✅ Event saved", event: newEvent });

    } catch (error) {
        console.error("❌ Error saving event:", error);
        res.status(500).json({ error: "Server error" });
    }
};