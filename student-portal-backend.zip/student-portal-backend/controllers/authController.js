const Student = require("../models/Student");
const Admin = require("../models/Admin");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "my_secret_key";

const generateToken = (id) => {
    return jwt.sign({ id }, JWT_SECRET, { expiresIn: "7d" });
};

exports.studentLogin = async(req, res) => {
    try {
        const { email, password, year } = req.body;

        if (!email || !password || !year) {
            return res.status(400).json({ message: "All fields are required" });
        }

        let student = await Student.findOne({ email, year });

        if (!student) {
            console.log("🆕 Registering new student:", email, year);
            const hashedPassword = await bcrypt.hash(password, 10);
            student = await Student.create({ email, password: hashedPassword, year });
            console.log("✅ Student saved:", student); // << log this to see it's saved
        }

        // Student exists → validate password
        const isMatch = await bcrypt.compare(password, student.password);
        if (!isMatch) {
            return res.status(401).json({ message: "❌ Incorrect password" });
        }

        return res.status(200).json({
            message: "✅ Login successful",
            token: generateToken(student._id),
        });

    } catch (err) {
        return res.status(500).json({ message: "Server error", error: err.message });
    }
};

// admin logiv for the codee okie 
exports.adminLogin = async(req, res) => {
    try {
        const { email, password } = req.body;

        // 1️⃣ Find admin by email
        const admin = await Admin.findOne({ email });
        if (!admin) {
            return res.status(404).json({ message: "❌ Admin not found" });
        }

        // 2️⃣ Compare password
        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ message: "❌ Invalid password" });
        }

        // 3️⃣ Create token
        const token = jwt.sign({ id: admin._id, role: admin.role },
            JWT_SECRET, { expiresIn: "7d" }
        );

        return res.status(200).json({
            message: "✅ Admin login successful",
            token,
            role: admin.role,
        });

    } catch (err) {
        console.error("Admin Login Error:", err);
        return res.status(500).json({ message: "❌ Server error", error: err.message });
    }
};